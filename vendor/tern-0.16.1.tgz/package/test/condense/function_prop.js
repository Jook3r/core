foo = function() {};
foo.s = '';
